from django.apps import AppConfig


class DojoNinjaConfig(AppConfig):
    name = 'Dojo_Ninja'

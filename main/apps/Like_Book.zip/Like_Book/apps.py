from django.apps import AppConfig


class LikeUsersConfig(AppConfig):
    name = 'Like_Users'
